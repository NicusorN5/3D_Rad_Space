#include "$fileinputname$.hpp"

using namespace Engine3DRadSpace;
using namespace Engine3DRadSpace::Objects;

$className$::$className$() : $base$()
{
}

void $className$::Initialize()
{
	//Add your own code (initialization logic)
}

void $className$::Load()
{
	//Add your own code (load from path that was specified before call/ctor call/etc)
}

void $className$::Load(const std::filesystem::path& path)
{
	//Add your own code (load from path)
}

void $className$::Update()
{
	//Add your own update logic (each frame)
}

$drawImplementation$

Reflection::UUID $className$::GetUUID() const noexcept
{
	// $guidText$
	return $guid$;
}