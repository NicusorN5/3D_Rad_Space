#pragma once
#include <Engine3DRadSpace/Objects/$base$.hpp>

class $className$ : public Engine3DRadSpace::Objects::$base$
{
public:
	$className$();

	void Initialize() override;
	void Load() override;
	void Load(const std::filesystem::path& path) override;
	void Update() override;
	$drawDeclaration$
	Engine3DRadSpace::Reflection::UUID GetUUID() const noexcept override;

	~$className$() override = default;
};