#include <Engine3DRadSpace/Plugins/PluginInfo.hpp>
#include <Engine3DRadSpace/Plugins/EditorPlugin.hpp>

using namespace Engine3DRadSpace;
using namespace Engine3DRadSpace::Plugins;

extern "C" {
	PluginInfo LoadPluginInfo()
	{
		//Fill in this struct with your own information.
		PluginInfo info;
		info.Name = "My Plugin";
		info.Version = "1.0.0";
		info.Author = "";
		info.Description = "";
		info.Homepage = "";
		info.IconFilename = "";

		return info;
	}

	bool PluginMain()
	{
		return true;
	}

	bool PluginUnload()
	{
		return true;
	}
}