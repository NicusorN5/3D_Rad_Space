#include <Engine3DRadSpace/Games/Game.hpp>

class MyGame : public Engine3DRadSpace::Game
{
public:
	MyGame() : Game("MyGame") 
	{
		//AppendScene("");
	}
	~MyGame() override = default;
};

int main()
{
	MyGame game;
	game.Run();
}